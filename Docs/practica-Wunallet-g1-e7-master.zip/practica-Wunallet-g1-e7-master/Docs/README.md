# Link de archivos

- Información general del procedimiento y lógica. [Aquí](https://github.com/POO2022-01-UNALMED/practica-Wunallet-g1-e7/blob/master/Docs/WunalletPOO.md)

- Diagrama de clases[Aquí](https://github.com/POO2022-01-UNALMED/practica-Wunallet-g1-e7/blob/master/Docs/Diagrama%20de%20clases%20Wunallet.drawio.png)

